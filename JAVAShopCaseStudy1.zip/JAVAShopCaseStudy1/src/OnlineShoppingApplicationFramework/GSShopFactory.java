package OnlineShoppingApplicationFramework;

public class GSShopFactory extends ShopFactory {
	
	GSPrimeAcc p=new GSPrimeAcc(101, "Jay", 10, false) ;
	GSNormalAcc n=new GSNormalAcc(102, "Anjali", 22, 50);
	public GSPrimeAcc getNewPrimeAcc(int accNo, String accNm, float charges, boolean isPrime)
	{
		return p;
		
	}
	
	public GSNormalAcc getNewNormalAcc(int accNo, String accNm, float charges, float deliveryCharges)
	{
		return n;
		
	}
}
