package OnlineShoppingApplicationFramework;

public abstract class PrimeAcc extends ShopAcc {
	
	private final boolean isPrime;
	private static final float deliveryCharges = 0;
	
	public PrimeAcc(int accNo, String accNm, float charges, boolean isPrime) {
		super(accNo, accNm, charges);
		this.isPrime = isPrime;
	}

	@Override
	public void bookProduct(float amt)
	{
		System.out.println("Book product overriden method in PrimeAcc class");
	}

	@Override
	public String toString() {
		return "PrimeAcc [isPrime=" + isPrime + " accno= "+super.getAccNo()+" AccNAme= "+super.getAccNm()+" charges= "+super.getCharges()+"]";
	}
	

	
	
	

}
