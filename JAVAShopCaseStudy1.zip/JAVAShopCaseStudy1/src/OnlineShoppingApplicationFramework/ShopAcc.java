package OnlineShoppingApplicationFramework;

public abstract class ShopAcc {
	private final int accNo;
	private String accNm;
	private final float charges;
	
	
	public ShopAcc(int accNo, String accNm, float charges) {
		super();
		this.accNo = accNo;
		this.accNm = accNm;
		this.charges = charges;
	}
	
	
	public int getAccNo() {
		return accNo;
	}


	public String getAccNm() {
		return accNm;
	}


	public float getCharges() {
		return charges;
	}


	public void setAccNm(String accNm) {
		this.accNm = accNm;
	}


	public void bookProduct(float amt)
	{
		System.out.println("Book Product method..");
	}
	
	public void items(float tot)
	{
		System.out.println("items method..");
	}

	@Override
	public String toString() {
		return "ShopAcc [accNo=" + accNo + ", accNm=" + accNm + ", charges=" + charges + "]";
	}
	
	

}
