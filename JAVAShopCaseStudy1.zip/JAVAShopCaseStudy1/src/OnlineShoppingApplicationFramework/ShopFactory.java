package OnlineShoppingApplicationFramework;

public abstract class ShopFactory {
	PrimeAcc p;
	NormalAcc n;
	public PrimeAcc getNewPrimeAcc(int accNo, String accNm, float charges, boolean isPrime)
	{
		return p;
		
	}
	
	public NormalAcc getNewNormalAcc(int accNo, String accNm, float charges, float deliveryCharges)
	{
		return n;
		
	}

}
