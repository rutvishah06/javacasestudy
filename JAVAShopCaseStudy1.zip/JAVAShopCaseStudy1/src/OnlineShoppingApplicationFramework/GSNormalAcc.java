package OnlineShoppingApplicationFramework;

public class GSNormalAcc extends NormalAcc{

	public GSNormalAcc(int accNo, String accNm, float charges, float deliveryCharges) {
		super(accNo, accNm, charges, deliveryCharges);
		
	}

	@Override
	public void bookProduct(float amt)
	{
		System.out.println("Book product overriden method in GSNormalAcc class");
	}
	@Override
	public String toString() {
		return "GSNormalAcc [toString()=" + super.toString() +  "]";
	}
	
	

	
}
