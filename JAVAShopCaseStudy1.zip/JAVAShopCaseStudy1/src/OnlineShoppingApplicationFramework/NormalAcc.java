package OnlineShoppingApplicationFramework;

public abstract class NormalAcc extends ShopAcc{

	private final float deliveryCharges;

	public NormalAcc(int accNo, String accNm, float charges, float deliveryCharges) {
		super(accNo, accNm, charges);
		this.deliveryCharges = deliveryCharges;
	}
	
	@Override
	public void bookProduct(float amt)
	{
		System.out.println("Book product overriden method in NormalAcc class");
	}

	@Override
	public String toString() {
		return "NormalAcc [accno= "+super.getAccNo()+" AccNAme= "+super.getAccNm()+" charges= "+super.getCharges()+"deliveryCharges=" + deliveryCharges + "]";
	}
	
	
}
