package OnlineShoppingApplicationFramework;

public class EntryClass {
	public static void main(String args[])
	{
		//a. Assign instance of GSShopFactory to ShopFactory reference
		ShopFactory sf=new GSShopFactory();
		System.out.println(sf.getNewPrimeAcc(101, "Anjali", 10, false));
		System.out.println(sf.getNewNormalAcc(102, "Jay", 3, 4));
		
		//b. Instantiate GSPrimeAcc and refer it through reference PrimeAcc
		System.out.println("\n");
		PrimeAcc pa=new GSPrimeAcc(01, "Devanshi", 2, false);
		pa.bookProduct(22);
		System.out.println(pa);
		
		//c. Instantiate GSNormalAcc and refer it through reference NormalAcc.
		System.out.println("\n");
		NormalAcc na=new GSNormalAcc(02, "richa", 2, 30);
		na.bookProduct(22);
		System.out.println(pa);
		
		
	}

}
